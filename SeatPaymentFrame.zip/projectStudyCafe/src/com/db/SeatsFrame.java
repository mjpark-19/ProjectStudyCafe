package com.db;

import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JToggleButton;
import javax.swing.border.LineBorder;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

public class SeatsFrame {

	private JFrame frame;
	private JPanel bigPanel;
	private JButton[] btn = new JButton[32];	
	private JButton[] btn2 = new JButton[32];
	private JButton button;
	ImageIcon img1 , img2;
	private String seatNo;
	private String roomNo;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SeatsFrame window = new SeatsFrame();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public SeatsFrame() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("Codesta Sutdy Cafe");
		frame.getContentPane().setBackground(Color.GRAY);
		frame.setBounds(0, 0, 700, 800);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		bigPanel = new JPanel();
		bigPanel.setBorder(new LineBorder(null, 0));
		bigPanel.setBackground(Color.GRAY);
		bigPanel.setBounds(-9, -31, 700, 800);
		frame.getContentPane().add(bigPanel);
		bigPanel.setLayout(null);
		
		//�¼����ÿ� �г�
		JPanel miniPanel_seats = new JPanel();
		miniPanel_seats.setBorder(new LineBorder(new Color(255, 200, 0), 3));
		miniPanel_seats.setBackground(Color.GRAY);
		miniPanel_seats.setBounds(12, 112, 676, 676);
		bigPanel.add(miniPanel_seats);
		miniPanel_seats.setLayout(null);
		
		//�ǽð� �¼���Ȳ�� �г�
		JPanel miniPanel_selectedSeats = new JPanel();
		miniPanel_selectedSeats.setBorder(new LineBorder(new Color(255, 200, 0), 3));
		miniPanel_selectedSeats.setBackground(Color.GRAY);
		miniPanel_selectedSeats.setBounds(12, 112, 676, 676);
		bigPanel.add(miniPanel_selectedSeats);
		miniPanel_selectedSeats.setLayout(null);		
	
		//�ǽð� �¼� ��Ȳ �г� ��ư �߰�(����x)	
		for (int i = 0; i < btn2.length; i++) {
			btn2[i] = new JButton((i+1)+"");
			btn2[i].setBackground(Color.WHITE);
			btn2[i].setFont(new Font("����", Font.BOLD, 15));
			miniPanel_selectedSeats.add(btn2[i]);
		} 
		
		btn[0] = new JButton("1");
		btn[0].setFont(new Font("����", Font.BOLD, 15));
		btn[0].setBackground(Color.WHITE);
		btn[0].setBounds(12, 21, 60, 60);
		btn2[0].setBounds(12, 21, 60, 60);
		miniPanel_seats.add(btn[0]);
		
		btn[1] = new JButton("2");
		btn[1].setBackground(Color.WHITE);
		btn[1].setFont(new Font("����", Font.BOLD, 15));
		btn[1].setBounds(12, 91, 60, 60);
		btn2[1].setBounds(12, 91, 60, 60);
		miniPanel_seats.add(btn[1]);
		
		btn[2] = new JButton("3");
		btn[2].setBackground(Color.WHITE);
		btn[2].setFont(new Font("����", Font.BOLD, 15));
		btn[2].setBounds(12, 161, 60, 60);
		btn2[2].setBounds(12, 161, 60, 60);
		miniPanel_seats.add(btn[2]);
		
		btn[3]= new JButton("4");
		btn[3].setBackground(Color.WHITE);
		btn[3].setFont(new Font("����", Font.BOLD, 15));
		btn[3].setBounds(12, 231, 60, 60);
		btn2[3].setBounds(12, 231, 60, 60);
		miniPanel_seats.add(btn[3]);
		
		btn[4] = new JButton("5");
		btn[4].setBackground(Color.WHITE);
		btn[4].setFont(new Font("����", Font.BOLD, 15));
		btn[4].setBounds(12, 301, 60, 60);
		btn2[4].setBounds(12, 301, 60, 60);
		miniPanel_seats.add(btn[4]);
		
		btn[5] = new JButton("6");
		btn[5].setBackground(Color.WHITE);
		btn[5].setFont(new Font("����", Font.BOLD, 15));
		btn[5].setBounds(12, 482, 60, 60);
		btn2[5].setBounds(12, 482, 60, 60);
		miniPanel_seats.add(btn[5]);
		
		btn[6] = new JButton("7");
		btn[6].setBackground(Color.WHITE);
		btn[6].setFont(new Font("����", Font.BOLD, 15));
		btn[6].setBounds(12, 552, 60, 60);
		btn2[6].setBounds(12, 552, 60, 60);
		miniPanel_seats.add(btn[6]);
		
		btn[7]= new JButton("8");
		btn[7].setBackground(Color.WHITE);
		btn[7].setFont(new Font("����", Font.BOLD, 15));
		btn[7].setBounds(147, 21, 60, 60);
		btn2[7].setBounds(147, 21, 60, 60);
		miniPanel_seats.add(btn[7]);
		
		btn[8] = new JButton("9");
		btn[8].setBackground(Color.WHITE);
		btn[8].setFont(new Font("����", Font.BOLD, 15));
		btn[8].setBounds(218, 21, 60, 60);
		btn2[8].setBounds(218, 21, 60, 60);
		miniPanel_seats.add(btn[8]);

		btn[9] = new JButton("10");
		btn[9].setBackground(Color.WHITE);
		btn[9].setFont(new Font("����", Font.BOLD, 15));
		btn[9].setBounds(290, 21, 60, 60);
		btn2[9].setBounds(290, 21, 60, 60);
		miniPanel_seats.add(btn[9]);
		
		btn[10] = new JButton("11");
		btn[10].setBackground(Color.WHITE);
		btn[10].setFont(new Font("����", Font.BOLD, 15));
		btn[10].setBounds(361, 21, 60, 60);
		btn2[10].setBounds(361, 21, 60, 60);
		miniPanel_seats.add(btn[10]);
			
		btn[11] = new JButton("12");
		btn[11].setBackground(Color.WHITE);
		btn[11].setFont(new Font("����", Font.BOLD, 15));
		btn[11].setBounds(433, 21, 60, 60);
		btn2[11].setBounds(433, 21, 60, 60);
		miniPanel_seats.add(btn[11]);
		
		btn[12] = new JButton("13");
		btn[12].setBackground(Color.WHITE);
		btn[12].setFont(new Font("����", Font.BOLD, 15));
		btn[12].setBounds(178, 161, 60, 60);
		btn2[12].setBounds(178, 161, 60, 60);
		miniPanel_seats.add(btn[12]);
		
		btn[13] = new JButton("14");
		btn[13].setBackground(Color.WHITE);
		btn[13].setFont(new Font("����", Font.BOLD, 15));
		btn[13].setBounds(250, 161, 60, 60);
		btn2[13].setBounds(250, 161, 60, 60);
		miniPanel_seats.add(btn[13]);
		
		btn[14] = new JButton("15");
		btn[14].setBackground(Color.WHITE);
		btn[14].setFont(new Font("����", Font.BOLD, 15));
		btn[14].setBounds(178, 231, 60, 60);
		btn2[14].setBounds(178, 231, 60, 60);
		miniPanel_seats.add(btn[14]);
		
		btn[15] = new JButton("16");
		btn[15].setBackground(Color.WHITE);
		btn[15].setFont(new Font("����", Font.BOLD, 15));
		btn[15].setBounds(250, 231, 60, 60);
		btn2[15].setBounds(250, 231, 60, 60);
		miniPanel_seats.add(btn[15]);
		
		btn[16] = new JButton("17");
		btn[16].setBackground(Color.WHITE);
		btn[16].setFont(new Font("����", Font.BOLD, 15));
		btn[16].setBounds(178, 301, 60, 60);
		btn2[16].setBounds(178, 301, 60, 60);
		miniPanel_seats.add(btn[16]);
		
		btn[17] = new JButton("18");
		btn[17].setBackground(Color.WHITE);
		btn[17].setFont(new Font("����", Font.BOLD, 15));
		btn[17].setBounds(250, 301, 60, 60);
		btn2[17].setBounds(250, 301, 60, 60);
		miniPanel_seats.add(btn[17]);
		
		btn[18] = new JButton("19");
		btn[18].setBackground(Color.WHITE);
		btn[18].setFont(new Font("����", Font.BOLD, 15));
		btn[18].setBounds(178, 482, 60, 60);
		btn2[18].setBounds(178, 482, 60, 60);
		miniPanel_seats.add(btn[18]);
		
		btn[19] = new JButton("20");
		btn[19].setBackground(Color.WHITE);
		btn[19].setFont(new Font("����", Font.BOLD, 15));
		btn[19].setBounds(250, 482, 60, 60);
		btn2[19].setBounds(250, 482, 60, 60);
		miniPanel_seats.add(btn[19]);
		
		btn[20] = new JButton("21");
		btn[20].setBackground(Color.WHITE);
		btn[20].setFont(new Font("����", Font.BOLD, 15));
		btn[20].setBounds(178, 552, 60, 60);
		btn2[20].setBounds(178, 552, 60, 60);
		miniPanel_seats.add(btn[20]);
		
		btn[21] = new JButton("22");
		btn[21].setBackground(Color.WHITE);
		btn[21].setFont(new Font("����", Font.BOLD, 15));
		btn[21].setBounds(250, 552, 60, 60);
		btn2[21].setBounds(250, 552, 60, 60);
		miniPanel_seats.add(btn[21]);
		
		btn[22] = new JButton("23");
		btn[22].setBackground(Color.WHITE);
		btn[22].setFont(new Font("����", Font.BOLD, 15));
		btn[22].setBounds(373, 161, 60, 60);
		btn2[22].setBounds(373, 161, 60, 60);
		miniPanel_seats.add(btn[22]);
		
		btn[23] = new JButton("24");
		btn[23].setBackground(Color.WHITE);
		btn[23].setFont(new Font("����", Font.BOLD, 15));
		btn[23].setBounds(445, 161, 60, 60);
		btn2[23].setBounds(445, 161, 60, 60);
		miniPanel_seats.add(btn[23]);
		
		btn[24] = new JButton("25");
		btn[24].setBackground(Color.WHITE);
		btn[24].setFont(new Font("����", Font.BOLD, 15));
		btn[24].setBounds(373, 231, 60, 60);
		btn2[24].setBounds(373, 231, 60, 60);
		miniPanel_seats.add(btn[24]);
		
		btn[25] = new JButton("26");
		btn[25].setBackground(Color.WHITE);
		btn[25].setFont(new Font("����", Font.BOLD, 15));
		btn[25].setBounds(445, 231, 60, 60);
		btn2[25].setBounds(445, 231, 60, 60);
		miniPanel_seats.add(btn[25]);
		
		btn[26] = new JButton("27");
		btn[26].setBackground(Color.WHITE);
		btn[26].setFont(new Font("����", Font.BOLD, 15));
		btn[26].setBounds(604, 21, 60, 60);
		btn2[26].setBounds(604, 21, 60, 60);
		miniPanel_seats.add(btn[26]);
		
		btn[27] = new JButton("28");
		btn[27].setBackground(Color.WHITE);
		btn[27].setFont(new Font("����", Font.BOLD, 15));
		btn[27].setBounds(604, 91, 60, 60);
		btn2[27].setBounds(604, 91, 60, 60);
		miniPanel_seats.add(btn[27]);
		
		btn[28] = new JButton("29");
		btn[28].setBackground(Color.WHITE);
		btn[28].setFont(new Font("����", Font.BOLD, 15));
		btn[28].setBounds(604, 161, 60, 60);
		btn2[28].setBounds(604, 161, 60, 60);
		miniPanel_seats.add(btn[28]);
		
		btn[29] = new JButton("30");
		btn[29].setBackground(Color.WHITE);
		btn[29].setFont(new Font("����", Font.BOLD, 15));
		btn[29].setBounds(604, 231, 60, 60);
		btn2[29].setBounds(604, 231, 60, 60);
		miniPanel_seats.add(btn[29]);
	
		btn[30] = new JButton("31");
		btn[30].setBackground(Color.WHITE);
		btn[30].setFont(new Font("����", Font.BOLD, 15));
		btn[30].setBounds(539, 394, 125, 125);
		btn2[30].setBounds(539, 394, 125, 125);
		miniPanel_seats.add(btn[30]);
		
		btn[31] = new JButton("32");
		btn[31].setBackground(Color.WHITE);
		btn[31].setFont(new Font("����", Font.BOLD, 15));
		btn[31].setBounds(539, 529, 125, 125);
		btn2[31].setBounds(539, 529, 125, 125);
		miniPanel_seats.add(btn[31]);	
		
		
		
	
	
//		�����¼� tmepInfo�� ����
		ArrayList<String> tempInfo = new ArrayList<String>();
		for (int i = 0; i < btn.length; i++) {
			btn[i].addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {	
					button = (JButton) e.getSource();
					button.setBackground(Color.yellow);			
					//����Ȯ��â
					String[] answer = {"����", "���"};
					int ans = JOptionPane.showOptionDialog(button, "�����Ͻðڽ��ϱ�?", "�¼�����", 
							JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE, null, answer, answer[0]);
					System.out.println("Answer:" + ans );
					//����ȯ��â���� '����'�� Ŭ���� ��� 
					if(ans==0) {
						button.setBackground(Color.DARK_GRAY);
						button.setEnabled(false);
						button.setText(e.getActionCommand());
						
						if (Integer.parseInt(button.getText())<30) {
							seatNo = button.getText();
						}else roomNo = button.getText();
							System.out.println("���ν� �¼���ȣ"+seatNo);
							System.out.println("5�ν� �¼���ȣ"+roomNo);
						tempInfo.add(seatNo);
						tempInfo.add(roomNo);
						System.out.println(seatNo+"/"+roomNo);
						System.out.println("�ӽ�����"+tempInfo);
						
					//����Ȯ��â���� '���'�� Ŭ���� ��� 
					}else button.setBackground(Color.WHITE);
				}
			});
		}
		
		

		miniPanel_seats.setVisible(false);
		miniPanel_selectedSeats.setVisible(false);
		
		//���� �г� (����-�����, ���-��밡��) 
		img1 = new ImageIcon("UserInfo\\white.png");
		img2 = new ImageIcon("UserInfo\\darkgray.png");
		
		JPanel minipanel_status = new JPanel();
		minipanel_status.setBounds(12, 45, 676, 57);
		bigPanel.add(minipanel_status);
		minipanel_status.setBorder(null);
		minipanel_status.setBackground(Color.GRAY);
		minipanel_status.setLayout(null);
		JLabel uavailable = new JLabel("\uC774\uC6A9\uAC00\uB2A5",img1,JLabel.LEFT);
		uavailable.setForeground(Color.WHITE);
		uavailable.setBounds(12, 10, 93, 37);
		minipanel_status.add(uavailable);
		
		JLabel available = new JLabel("\uC774\uC6A9\uC911", img2,JLabel.LEFT);
		available.setForeground(Color.WHITE);
		available.setBounds(130, 10, 93, 37);
		minipanel_status.add(available);
		
		//ȭ�� ��ȯ ��ư
		JToggleButton btnSwitch = new JToggleButton("\uC2E4\uC2DC\uAC04");
		btnSwitch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (btnSwitch.isSelected()) {
					miniPanel_selectedSeats.setVisible(!miniPanel_selectedSeats.isVisible());
				}else miniPanel_seats.setVisible(!miniPanel_seats.isVisible());
			}
		});
		btnSwitch.setForeground(Color.WHITE);
		btnSwitch.setBackground(Color.ORANGE);
		btnSwitch.setFont(new Font("����", Font.BOLD, 15));
		btnSwitch.setBounds(480, 0, 155, 47);
		minipanel_status.add(btnSwitch);
	
		
}
	
	
	
	//��ư�̺�Ʈ(�¼� ���� �̺�Ʈ)
	void Seats() {
		//�����¼� tmepInfo�� ����
		ArrayList<String> tempInfo = new ArrayList<String>();
		for (int i = 0; i < btn.length; i++) {
			btn[i].addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {	
					button = (JButton) e.getSource();
					button.setBackground(Color.yellow);			
					//����Ȯ��â
					String[] answer = {"����", "���"};
					int ans = JOptionPane.showOptionDialog(button, "�����Ͻðڽ��ϱ�?", "�¼�����", 
							JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE, null, answer, answer[0]);
					System.out.println("Answer:" + ans );
					//����ȯ��â���� '����'�� Ŭ���� ��� 
					if(ans==0) {
						button.setBackground(Color.DARK_GRAY);
						button.setEnabled(false);
						button.setText(e.getActionCommand());
						if (Integer.parseInt(button.getText())<30) {
							seatNo = button.getText();
							}else roomNo = button.getText();
						System.out.println("���ν� �¼���ȣ"+seatNo);
						System.out.println("5�ν� �¼���ȣ"+roomNo);
						tempInfo.add(seatNo);
						tempInfo.add(roomNo);
						System.out.println(seatNo+"/"+roomNo);
					}//����Ȯ��â���� '���'�� Ŭ���� ��� 
					else button.setBackground(Color.WHITE);
				} 		
			});
		}
	}
	//�׼Ǹ����� Ŭ�� �и��� ���(���x)
	void btnEventTst(JPanel panel) {
		for (int i = 0; i < btn.length; i++) {
				btn[i].addActionListener(new BtnEvent(btn[i]));
		}
	}
}