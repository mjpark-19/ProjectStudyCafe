package com.db;

import java.awt.Color;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;
import javax.swing.JOptionPane;


public class EventTst1 implements MouseListener {
	
	JButton button;
	int ans = 0;

	
	public EventTst1() {
	}
	public EventTst1(JButton button) {
		this.button=button;
	}
	


	
	
	@Override
	public void mouseClicked(MouseEvent e) {
		
		
	}
	@Override
	public void mousePressed(MouseEvent e) {
		button.setBackground(Color.yellow);
		
		String[] answer = {"����", "���"};
		int ans = JOptionPane.showOptionDialog(button, "�����Ͻðڽ��ϱ�?", "�¼�����", 
				JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE, null, answer, answer[0]);
		System.out.println("Answer:" + ans );
		if(ans==0) {
			button.setEnabled(false);
			button.setBackground(Color.DARK_GRAY);
		} else button.setBackground(Color.WHITE);
		}
		

	
	@Override
	public void mouseReleased(MouseEvent e) {
		
		
	}
	@Override
	public void mouseEntered(MouseEvent e) {

	}
	@Override
	public void mouseExited(MouseEvent e) {
		//button.setBackground(Color.WHITE);
		

	}
	
	
}
