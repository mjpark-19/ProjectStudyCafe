package com.db;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class BtnEvent implements ActionListener{
	ArrayList<upload> UserSeatNum = new ArrayList<upload>();
	JButton button;

	int ans = 0;

	
	public BtnEvent() {
	}
	public BtnEvent(JButton button) {
		this.button=button;
	}
	
	
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		button.setBackground(Color.yellow);
		
		String[] answer = {"����", "���"};
		int ans = JOptionPane.showOptionDialog(button, "�����Ͻðڽ��ϱ�?", "�¼�����", 
				JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE, null, answer, answer[0]);
		System.out.println("Answer:" + ans );
		if(ans==0) {
			button.setBackground(Color.DARK_GRAY);
			button.setEnabled(false);
			System.out.println(e.getActionCommand());
			
			
			
		} else button.setBackground(Color.WHITE);
		}
		
	}


